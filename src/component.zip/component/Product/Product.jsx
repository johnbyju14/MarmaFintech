import { useRef, useEffect } from 'react'
import './Product.css'

export default function Product() {
  const scrollContainerRef = useRef(null);

  useEffect(() => {
    const scrollContainer = scrollContainerRef.current;
    if (!scrollContainer) return;

    const handleWheel = (e) => {
      e.preventDefault();
      scrollContainer.scrollLeft += e.deltaY;
    };

    scrollContainer.addEventListener('wheel', handleWheel, { passive: false });

    return () => {
      scrollContainer.removeEventListener('wheel', handleWheel);
    };
  }, []);

  return (
    <div className="relative w-full min-h-screen  overflow-hidden">
        <div
          ref={scrollContainerRef}
          className="overflow-x-scroll scrollbar-hide"
        >
          <div className="flex space-x-4 pb-4 w-max">
            <div className="flex-shrink-0 w-[300px] h-[180px] rounded-xl bg-[#1a1f3c] text-white p-6">
              <div className="h-full flex flex-col justify-between">
                <div className="text-sm opacity-80">THEICON.ME</div>
                <div className="space-y-1">
                  <div className="text-xs opacity-60">Card Number</div>
                  <div className="font-mono">**** **** **** 1234</div>
                </div>
              </div>
            </div>

            <div className="flex-shrink-0 w-[300px] h-[180px] rounded-xl bg-[#3c1a1a] text-white p-6">
              <div className="h-full flex flex-col justify-between">
                <div className="text-sm opacity-80">COINCHAMP</div>
                <div className="space-y-1">
                  <div className="text-xs opacity-60">Card Number</div>
                  <div className="font-mono">**** **** **** 5678</div>
                </div>
              </div>
            </div>

            <div className="flex-shrink-0 w-[300px] h-[180px] rounded-xl bg-[#1a1a1a] text-white p-6">
              <div className="h-full flex flex-col justify-between">
                <div className="text-sm opacity-80">SQUAREHUT</div>
                <div className="space-y-1">
                  <div className="text-xs opacity-60">Card Number</div>
                  <div className="font-mono">**** **** **** 9012</div>
                </div>
              </div>
            </div>

            <div className="flex-shrink-0 w-[300px] h-[180px] rounded-xl bg-[#3c2a1a] text-white p-6">
              <div className="h-full flex flex-col justify-between">
                <div className="text-sm opacity-80">THEICON.COM</div>
                <div className="space-y-1">
                  <div className="text-xs opacity-60">Card Number</div>
                  <div className="font-mono">**** **** **** 3456</div>
                </div>
              </div>
            </div>
            <div className="flex-shrink-0 w-[300px] h-[180px] rounded-xl bg-[#3c2a1a] text-white p-6">
              <div className="h-full flex flex-col justify-between">
                <div className="text-sm opacity-80">THEICON.COM</div>
                <div className="space-y-1">
                  <div className="text-xs opacity-60">Card Number</div>
                  <div className="font-mono">**** **** **** 3456</div>
                </div>
              </div>
            </div>
            <div className="flex-shrink-0 w-[300px] h-[180px] rounded-xl bg-[#3c2a1a] text-white p-6">
              <div className="h-full flex flex-col justify-between">
                <div className="text-sm opacity-80">THEICON.COM</div>
                <div className="space-y-1">
                  <div className="text-xs opacity-60">Card Number</div>
                  <div className="font-mono">**** **** **** 3456</div>
                </div>
              </div>
            </div>
            <div className="flex-shrink-0 w-[300px] h-[180px] rounded-xl bg-[#3c2a1a] text-white p-6">
              <div className="h-full flex flex-col justify-between">
                <div className="text-sm opacity-80">THEICON.COM</div>
                <div className="space-y-1">
                  <div className="text-xs opacity-60">Card Number</div>
                  <div className="font-mono">**** **** **** 3456</div>
                </div>
              </div>
            </div>
            <div className="flex-shrink-0 w-[300px] h-[180px] rounded-xl bg-[#3c2a1a] text-white p-6">
              <div className="h-full flex flex-col justify-between">
                <div className="text-sm opacity-80">THEICON.COM</div>
                <div className="space-y-1">
                  <div className="text-xs opacity-60">Card Number</div>
                  <div className="font-mono">**** **** **** 3456</div>
                </div>
              </div>
            </div>     
          </div>
        </div>
    </div>
  );
}
